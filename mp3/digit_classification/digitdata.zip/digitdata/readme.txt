optdigits-orig_train.txt contains all the training dataset for digits 0-9. For each digit, the first thirty-two lines contains the 32x32
bitmap for each digit. 1 represents the foreground, and 0 represents the background. The succeeding line contains the label for that digit. 
optdigits-orig_test.txt contains all the testing dataset for digits 0-9. The data format is as same as the optdigits-orig_train.txt.
You should only use optdigits-orig_train dataset as your training data and optdigits-orig_test dataset as your testing data.

Resource:https://archive.ics.uci.edu/ml/machine-learning-databases/optdigits/